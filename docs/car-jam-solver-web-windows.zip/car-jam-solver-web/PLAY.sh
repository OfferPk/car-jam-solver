#!/usr/bin/env bash
cd "$(dirname "$0")"
echo "Car Jam Solver → http://localhost:4180"
(command -v python3 >/dev/null && python3 -m http.server 4180) || (command -v python >/dev/null && python -m http.server 4180)

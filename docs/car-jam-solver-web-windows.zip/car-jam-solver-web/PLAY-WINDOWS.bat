@echo off
cd /d "%~dp0"
echo Starting Car Jam Solver...
echo Open http://localhost:4180 in your browser
where py >nul 2>nul && (start http://localhost:4180 & py -m http.server 4180 & goto :eof)
where python >nul 2>nul && (start http://localhost:4180 & python -m http.server 4180 & goto :eof)
where python3 >nul 2>nul && (start http://localhost:4180 & python3 -m http.server 4180 & goto :eof)
echo No Python found. Open index.html directly in a browser (file://).
start index.html
